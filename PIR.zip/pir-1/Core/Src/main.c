/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : PIR 센서를 이용한 LED 제어 프로그램
  ******************************************************************************
  * @attention
  * - PIR 센서가 동작을 감지하면 LED를 켭니다.
  * - LED는 2초 동안 켜진 상태를 유지한 뒤 꺼집니다.
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"        // STM32 초기화 관련 헤더
#include "gpio.h"        // GPIO 설정 및 제어 관련 헤더

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define PIR_SENSOR_PIN GPIO_PIN_4      // PIR 센서 입력 핀
#define PIR_SENSOR_PORT GPIOA          // PIR 센서 포트

#define LED_PIN GPIO_PIN_0             // LED 출력 핀
#define LED_PORT GPIOB                 // LED 출력 포트

#define LED_ON  1                      // LED ON 상태
#define LED_OFF 0                      // LED OFF 상태
/* USER CODE END PD */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);         // 시스템 클럭 설정 함수

/* USER CODE BEGIN 0 */
/**
  * @brief  LED 상태를 설정하는 함수
  * @param  state : GPIO_PIN_SET (ON) 또는 GPIO_PIN_RESET (OFF)
  */
void Set_LED_State(GPIO_PinState state) {
    HAL_GPIO_WritePin(LED_PORT, LED_PIN, state); // LED 핀의 상태를 설정
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* MCU Configuration--------------------------------------------------------*/
  HAL_Init();                      // HAL 라이브러리 초기화
  SystemClock_Config();            // 시스템 클럭 설정
  MX_GPIO_Init();                  // GPIO 초기화 (PIR 센서 및 LED 설정)

  /* Infinite loop */
  while (1)
  {
      // PIR 센서가 모션을 감지했는지 확인
      if (HAL_GPIO_ReadPin(PIR_SENSOR_PORT, PIR_SENSOR_PIN) == GPIO_PIN_SET)
      {
          Set_LED_State(GPIO_PIN_SET); // LED 켜기
          HAL_Delay(2000);             // 2초 대기

          Set_LED_State(GPIO_PIN_RESET); // LED 끄기

          // PIR 센서의 입력 핀이 LOW 상태로 변할 때까지 대기
          while (HAL_GPIO_ReadPin(PIR_SENSOR_PORT, PIR_SENSOR_PIN));
      }

      HAL_Delay(500); // 다음 감지를 위한 대기 시간
  }
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
